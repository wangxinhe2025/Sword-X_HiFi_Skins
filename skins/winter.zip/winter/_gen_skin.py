"""Generate Winter skin assets: snowy dusk backdrop + ice-white / lamp-amber controls."""
from __future__ import annotations

import math
import shutil
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont

ROOT = Path(__file__).resolve().parent
SRC = Path(r"D:\compare\winter.png")
MOCKUPS = ROOT.parent / "mockups"
SCALE = 4

WHITE = (248, 252, 255, 255)
WHITE_SOFT = (236, 244, 252, 200)
# 路灯暖琥珀：hover 光晕；冰蓝：EQ/选中
AMBER = (232, 188, 112, 255)
AMBER_SOFT = (245, 218, 168, 255)
ICE = (168, 200, 228, 255)
ICE_SOFT = (198, 220, 240, 255)
INK_DIM = (220, 230, 242, 150)

MAIN_W, MAIN_H = 1229, 530
PL_W, PL_H = 1229, 430
EQ_W, EQ_H = 560, 540


def font_path() -> str:
    for name in ("segoeuil.ttf", "segoeui.ttf", "arial.ttf"):
        p = Path(r"C:\Windows\Fonts") / name
        if p.exists():
            return str(p)
    return None


FONT_FILE = font_path()


def load_font(px: float) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    if FONT_FILE:
        return ImageFont.truetype(FONT_FILE, int(px))
    return ImageFont.load_default()


def ensure(p: Path) -> Path:
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def new_hi(w: int, h: int) -> Image.Image:
    return Image.new("RGBA", (w * SCALE, h * SCALE), (0, 0, 0, 0))


def down(im: Image.Image, w: int, h: int) -> Image.Image:
    return im.resize((w, h), Image.Resampling.LANCZOS)


def save_png(im: Image.Image, rel: str) -> None:
    ensure(ROOT / rel)
    im.save(ROOT / rel, "PNG")


def with_glow(im: Image.Image, color=AMBER, radius: int = 6) -> Image.Image:
    a = im.split()[3]
    glow = Image.new("RGBA", im.size, color)
    glow.putalpha(a)
    glow = glow.filter(ImageFilter.GaussianBlur(radius))
    return Image.alpha_composite(glow, im)


def _clamp_alpha(im: Image.Image, peak: int) -> Image.Image:
    r, g, b, a = im.split()
    if peak < 255:
        a = a.point(lambda x, p=peak: min(p, x))
    return Image.merge("RGBA", (r, g, b, a))


def _halo_from_alpha(
    alpha: Image.Image, color: tuple[int, int, int, int], blur_r: int, peak: int
) -> Image.Image:
    layer = Image.new("RGBA", alpha.size, color[:3])
    layer.putalpha(alpha)
    layer = layer.filter(ImageFilter.GaussianBlur(max(2, blur_r)))
    return _clamp_alpha(layer, peak)


# 半透光晕统一淡蓝：alpha 再高也只是蓝色，不会把白图标染黄/串色
GLOW_BLUE = (168, 210, 245)


def compose_breathe_glow(im: Image.Image, *, checked: bool = False) -> Image.Image:
    """带 padding 的淡蓝软光晕（单一 RGB）。图标在缩小后再叠上。"""
    w, h = im.size
    m = min(w, h)
    pad = max(int(m * 0.42), 18)
    cw, ch = w + 2 * pad, h + 2 * pad

    base = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    base.paste(im, (pad, pad), im)
    alpha = base.split()[3]
    dilate = max(3, int(m * 0.12) | 1)
    alpha_wide = alpha.filter(ImageFilter.MaxFilter(dilate))

    peak_outer = 100 if checked else 85
    peak_inner = 150 if checked else 125
    out = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    out = Image.alpha_composite(
        out,
        _halo_from_alpha(alpha_wide, (*GLOW_BLUE, 255), max(5, int(m * 0.32)), peak_outer),
    )
    out = Image.alpha_composite(
        out,
        _halo_from_alpha(alpha_wide, (*GLOW_BLUE, 255), max(3, int(m * 0.14)), peak_inner),
    )
    px = out.load()
    br, bg, bb = GLOW_BLUE
    for y in range(ch):
        for x in range(cw):
            a = px[x, y][3]
            if a > 0:
                px[x, y] = (br, bg, bb, a)
    return out


def force_glow_blue(im: Image.Image) -> Image.Image:
    """半透区 RGB 强制为同一淡蓝（缩小后也要再跑一遍）。"""
    out = im.copy()
    px = out.load()
    br, bg, bb = GLOW_BLUE
    w, h = out.size
    for y in range(h):
        for x in range(w):
            a = px[x, y][3]
            if a > 0:
                px[x, y] = (br, bg, bb, a)
    return out


def stack_icon_on_glow(glow: Image.Image, icon: Image.Image) -> Image.Image:
    """白图标居中叠在淡蓝光晕上；笔触提纯为不透明白。"""
    glow = force_glow_blue(glow)
    ow, oh = glow.size
    iw, ih = icon.size
    hardened = icon.copy()
    px = hardened.load()
    for y in range(ih):
        for x in range(iw):
            r, g, b, a = px[x, y]
            if a <= 0:
                continue
            if a >= 40:
                if max(r, g, b) >= 180 and (max(r, g, b) - min(r, g, b)) <= 40:
                    r = g = b = 255
                px[x, y] = (r, g, b, 255)
    out = glow.copy()
    out.paste(hardened, ((ow - iw) // 2, (oh - ih) // 2), hardened)
    return out


def tint(im: Image.Image, color: tuple[int, int, int, int]) -> Image.Image:
    out = Image.new("RGBA", im.size, (0, 0, 0, 0))
    layer = Image.new("RGBA", im.size, color)
    layer.putalpha(im.split()[3])
    return Image.alpha_composite(out, layer)


def draw_line(d: ImageDraw.ImageDraw, a, b, fill, w: float) -> None:
    lw = max(1, int(round(w)))
    d.line([a, b], fill=fill, width=lw, joint="curve")
    r = lw / 2
    for x, y in (a, b):
        d.ellipse([x - r, y - r, x + r, y + r], fill=fill)


def icon_base(w: int, h: int):
    im = new_hi(w, h)
    d = ImageDraw.Draw(im)
    return im, d, w * SCALE, h * SCALE, SCALE


def finish_icon(im: Image.Image, w: int, h: int, rel: str, variant: str) -> None:
    if variant == "hover":
        hi = compose_breathe_glow(im)
        ow = max(1, int(round(hi.size[0] / SCALE)))
        oh = max(1, int(round(hi.size[1] / SCALE)))
        small = stack_icon_on_glow(down(hi, ow, oh), down(im, w, h))
    elif variant == "checked":
        hi = compose_breathe_glow(im, checked=True)
        ow = max(1, int(round(hi.size[0] / SCALE)))
        oh = max(1, int(round(hi.size[1] / SCALE)))
        small = stack_icon_on_glow(down(hi, ow, oh), down(im, w, h))
    elif variant == "pressed":
        small = tint(down(im, w, h), INK_DIM)
    else:
        small = down(im, w, h)
    save_png(small, rel)


def variants(im: Image.Image, w: int, h: int, folder: str, checked=False) -> None:
    finish_icon(im, w, h, f"{folder}/normal.png", "normal")
    finish_icon(im, w, h, f"{folder}/hover.png", "hover")
    finish_icon(im, w, h, f"{folder}/pressed.png", "pressed")
    if checked:
        finish_icon(im, w, h, f"{folder}/checked.png", "checked")


# ----- glyphs -----

def glyph_pause(d, W, H, s, fill=WHITE):
    cx, cy = W / 2, H / 2
    bw, bh, gap = 0.09 * W, 0.34 * H, 0.16 * W
    lw = 0.055 * min(W, H)
    for dx in (-gap / 2 - bw / 2, gap / 2 - bw / 2):
        x0, y0 = cx + dx, cy - bh / 2
        d.rounded_rectangle([x0, y0, x0 + bw, y0 + bh], radius=lw, fill=fill)


def glyph_play(d, W, H, s, fill=WHITE):
    cx, cy = W / 2 + 0.03 * W, H / 2
    aw, ah = 0.22 * W, 0.32 * H
    d.polygon(
        [(cx - aw * 0.55, cy - ah), (cx + aw, cy), (cx - aw * 0.55, cy + ah)],
        fill=fill,
    )


def glyph_stop(d, W, H, s, fill=WHITE):
    cx, cy = W / 2, H / 2
    a = 0.22 * min(W, H)
    r = 0.06 * min(W, H)
    d.rounded_rectangle([cx - a, cy - a, cx + a, cy + a], radius=r, fill=fill)


def glyph_prev(d, W, H, s, fill=WHITE):
    cx, cy = W / 2, H / 2
    lw = max(3, 0.07 * min(W, H))
    bar_x = cx - 0.22 * W
    d.rounded_rectangle([bar_x, cy - 0.22 * H, bar_x + lw, cy + 0.22 * H], radius=lw / 2, fill=fill)
    d.polygon(
        [
            (cx + 0.26 * W, cy - 0.24 * H),
            (cx - 0.08 * W, cy),
            (cx + 0.26 * W, cy + 0.24 * H),
        ],
        fill=fill,
    )


def glyph_next(d, W, H, s, fill=WHITE):
    cx, cy = W / 2, H / 2
    lw = max(3, 0.07 * min(W, H))
    bar_x = cx + 0.22 * W
    d.rounded_rectangle([bar_x - lw, cy - 0.22 * H, bar_x, cy + 0.22 * H], radius=lw / 2, fill=fill)
    d.polygon(
        [
            (cx - 0.26 * W, cy - 0.24 * H),
            (cx + 0.08 * W, cy),
            (cx - 0.26 * W, cy + 0.24 * H),
        ],
        fill=fill,
    )


def glyph_min(d, W, H, s, fill=WHITE):
    lw = max(3, 0.07 * min(W, H))
    y = H * 0.55
    d.rounded_rectangle([W * 0.22, y - lw / 2, W * 0.78, y + lw / 2], radius=lw / 2, fill=fill)


def glyph_close(d, W, H, s, fill=WHITE):
    lw = max(3, 0.065 * min(W, H))
    m = 0.28 * min(W, H)
    cx, cy = W / 2, H / 2
    draw_line(d, (cx - m, cy - m), (cx + m, cy + m), fill, lw)
    draw_line(d, (cx + m, cy - m), (cx - m, cy + m), fill, lw)


def glyph_menu(d, W, H, s, fill=WHITE):
    cx, cy = W / 2, H / 2
    r = max(3, 0.055 * min(W, H))
    gap = 0.18 * H
    for i in (-1, 0, 1):
        d.ellipse([cx - r, cy + i * gap - r, cx + r, cy + i * gap + r], fill=fill)


def glyph_list(d, W, H, s, fill=WHITE):
    lw = max(3, 0.055 * min(W, H))
    x0, x1 = W * 0.26, W * 0.74
    for i, yf in enumerate((0.32, 0.50, 0.68)):
        y = H * yf
        d.rounded_rectangle([x0, y - lw / 2, x1, y + lw / 2], radius=lw / 2, fill=fill)
        d.ellipse([x0 - 0.08 * W, y - lw / 2 - 1, x0 - 0.02 * W, y + lw / 2 + 1], fill=fill)


def glyph_eq(d, W, H, s, fill=WHITE):
    lw = max(4, 0.08 * min(W, H))
    cx, cy = W / 2, H / 2
    bars = [0.22, 0.38, 0.16]
    gap = 0.18 * W
    for i, hfrac in enumerate(bars):
        x = cx + (i - 1) * gap
        h = hfrac * H * 2
        d.rounded_rectangle([x - lw / 2, cy - h / 2, x + lw / 2, cy + h / 2], radius=lw / 2, fill=fill)


def glyph_speaker(d, W, H, s, fill=WHITE):
    cx, cy = W / 2 - 0.06 * W, H / 2
    lw = max(3, 0.055 * min(W, H))
    d.polygon(
        [
            (cx - 0.12 * W, cy - 0.12 * H),
            (cx + 0.02 * W, cy - 0.22 * H),
            (cx + 0.02 * W, cy + 0.22 * H),
            (cx - 0.12 * W, cy + 0.12 * H),
        ],
        fill=fill,
    )
    d.rounded_rectangle(
        [cx - 0.22 * W, cy - 0.10 * H, cx - 0.08 * W, cy + 0.10 * H],
        radius=lw / 2,
        fill=fill,
    )
    for i, r in enumerate((0.16, 0.26)):
        box = [cx + 0.04 * W, cy - r * H, cx + 0.04 * W + r * W * 1.4, cy + r * H]
        d.arc(box, start=-50, end=50, fill=fill, width=int(lw))


def glyph_seq(d, W, H, s, fill=WHITE):
    cx, cy = W / 2, H / 2
    for i in range(3):
        x = cx + (i - 1) * 0.22 * W
        d.polygon(
            [(x + 0.10 * W, cy), (x - 0.06 * W, cy - 0.16 * H), (x - 0.06 * W, cy + 0.16 * H)],
            fill=fill,
        )


def glyph_loop(d, W, H, s, fill=WHITE):
    cx, cy = W / 2, H / 2
    lw = max(3, 0.06 * min(W, H))
    box = [cx - 0.28 * W, cy - 0.22 * H, cx + 0.28 * W, cy + 0.22 * H]
    d.arc(box, 20, 340, fill=fill, width=int(lw))
    d.polygon(
        [
            (cx + 0.18 * W, cy - 0.28 * H),
            (cx + 0.02 * W, cy - 0.08 * H),
            (cx + 0.32 * W, cy - 0.06 * H),
        ],
        fill=fill,
    )


def glyph_shuffle(d, W, H, s, fill=WHITE):
    cx, cy = W / 2, H / 2
    lw = max(3, 0.055 * min(W, H))
    # 交叉路径：上左→下右、下左→上右
    draw_line(d, (cx - 0.28 * W, cy - 0.18 * H), (cx + 0.02 * W, cy - 0.18 * H), fill, lw)
    d.arc([cx - 0.08 * W, cy - 0.18 * H, cx + 0.18 * W, cy + 0.18 * H], -90, 90, fill=fill, width=int(lw))
    draw_line(d, (cx - 0.28 * W, cy + 0.18 * H), (cx + 0.02 * W, cy + 0.18 * H), fill, lw)
    d.polygon(
        [(cx + 0.32 * W, cy + 0.18 * H), (cx + 0.14 * W, cy + 0.04 * H), (cx + 0.14 * W, cy + 0.32 * H)],
        fill=fill,
    )
    d.polygon(
        [(cx + 0.32 * W, cy - 0.18 * H), (cx + 0.14 * W, cy - 0.32 * H), (cx + 0.14 * W, cy - 0.04 * H)],
        fill=fill,
    )


def glyph_loop_one(d, W, H, s, fill=WHITE):
    glyph_loop(d, W, H, s, fill)
    f = load_font(0.28 * H)
    d.text((W * 0.42, H * 0.32), "1", font=f, fill=fill)


def make_button(w, h, glyph, folder, checked=False):
    im, d, W, H, s = icon_base(w, h)
    glyph(d, W, H, s)
    variants(im, w, h, folder, checked=checked)


def make_led(w, h, glyph, rel_on, rel_off):
    im, d, W, H, s = icon_base(w, h)
    glyph(d, W, H, s)
    save_png(with_glow(down(im, w, h), AMBER, 2), rel_on)
    save_png(tint(down(im, w, h), INK_DIM), rel_off)


def make_play_state():
    specs = [
        ("playing", glyph_play),
        ("paused", glyph_pause),
        ("stopped", glyph_stop),
    ]
    for name, g in specs:
        im, d, W, H, s = icon_base(28, 28)
        g(d, W, H, s)
        save_png(down(im, 28, 28), f"leds/play_state/{name}.png")


def make_play_mode():
    for name, g in (
        ("sequential", glyph_seq),
        ("loop_all", glyph_loop),
        ("shuffle", glyph_shuffle),
        ("loop_one", glyph_loop_one),
    ):
        im, d, W, H, s = icon_base(44, 44)
        g(d, W, H, s)
        save_png(down(im, 44, 44), f"edited/main_play_mode/{name}.png")
    shutil.copy(ROOT / "edited/main_play_mode/sequential.png", ROOT / "edited/main_play_mode/normal.png")
    im, d, W, H, s = icon_base(44, 44)
    glyph_seq(d, W, H, s)
    finish_icon(im, 44, 44, "edited/main_play_mode/pressed.png", "pressed")


def make_speaker():
    im, d, W, H, s = icon_base(28, 28)
    glyph_speaker(d, W, H, s)
    save_png(down(im, 28, 28), "icons/speaker.png")


def make_circle_thumb(size: int, rel: str, hover=False, pressed=False):
    im, d, W, H, s = icon_base(size, size)
    pad = int(0.06 * W)
    fill = WHITE_SOFT if pressed else WHITE
    d.ellipse([pad, pad, W - pad - 1, H - pad - 1], fill=fill)
    if hover:
        hi = compose_breathe_glow(im)
        ow = max(1, int(round(hi.size[0] / SCALE)))
        oh = max(1, int(round(hi.size[1] / SCALE)))
        save_png(stack_icon_on_glow(down(hi, ow, oh), down(im, size, size)), rel)
    else:
        save_png(down(im, size, size), rel)


def make_bar(w: int, h: int, color, rel: str, radius: bool = True):
    im, d, W, H, s = icon_base(w, h)
    r = H / 2 if radius else 0
    d.rounded_rectangle([0, 0, W - 1, H - 1], radius=r, fill=color)
    save_png(down(im, w, h), rel)


def make_eq_slot():
    w, h = 10, 380
    im, d, W, H, s = icon_base(w, h)
    x0, x1 = W * 0.22, W * 0.78
    d.rounded_rectangle([x0, 0, x1, H], radius=(x1 - x0) / 2, fill=(255, 255, 255, 55))
    save_png(down(im, w, h), "sliders/eq_slot.png")
    im2, d2, W2, H2, _ = icon_base(w, 120)
    d2.rounded_rectangle([W2 * 0.22, 0, W2 * 0.78, H2], radius=4, fill=ICE)
    save_png(down(im2, w, 120), "sliders/eq_fill.png")


def make_eq_thumb():
    for name, hover, pressed in (("normal", False, False), ("hover", True, False), ("pressed", False, True)):
        make_circle_thumb(30, f"sliders/eq_thumb/{name}.png", hover=hover, pressed=pressed)


def make_seek_volume():
    # track/fill 细条；thumb 加大（CSS 里 seek/volume 高度也要跟细条对齐，避免被拉伸变粗）
    make_bar(64, 3, (255, 255, 255, 72), "sliders/seek_track.png")
    make_bar(64, 3, WHITE, "sliders/seek_fill.png")
    make_circle_thumb(28, "sliders/seek_thumb/normal.png")
    make_circle_thumb(28, "sliders/seek_thumb/hover.png", hover=True)
    make_circle_thumb(28, "sliders/seek_thumb/pressed.png", pressed=True)
    make_bar(64, 2, (255, 255, 255, 72), "sliders/volume_track.png")
    make_bar(64, 2, WHITE, "sliders/volume_fill.png")
    make_circle_thumb(22, "sliders/volume_thumb/normal.png")
    make_circle_thumb(22, "sliders/volume_thumb/pressed.png", pressed=True)


def make_row_selected():
    im = Image.new("RGBA", (8, 50), (168, 200, 228, 72))
    save_png(im, "playlist/row_selected.png")


def make_lcd():
    dw, dh = 26, 40
    glyphs = list("0123456789") + [":", "-", " "]
    names = [str(i) for i in range(10)] + ["colon", "dash", "blank"]
    f = load_font(36 * SCALE)
    for g, name in zip(glyphs, names):
        im = new_hi(dw if g != ":" else 14, dh)
        d = ImageDraw.Draw(im)
        W, H = im.size
        if g != " ":
            bbox = d.textbbox((0, 0), g, font=f)
            tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
            d.text(((W - tw) / 2 - bbox[0], (H - th) / 2 - bbox[1]), g, font=f, fill=WHITE)
        save_png(down(im, dw if g != ":" else 14, dh), f"lcd/digit_{name}.png")


def vignette_bars(rgb: Image.Image, top: int, bottom: int) -> Image.Image:
    im = rgb.convert("RGBA")
    w, h = im.size
    overlay = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    pix = overlay.load()
    for y in range(top):
        a = int(110 * (1 - y / max(1, top)))
        for x in range(w):
            pix[x, y] = (22, 36, 54, a)
    for i, y in enumerate(range(h - bottom, h)):
        a = int(140 * ((i + 1) / bottom))
        for x in range(w):
            pix[x, y] = (28, 42, 62, min(150, a))
    return Image.alpha_composite(im, overlay)


def make_windows():
    src = Image.open(SRC).convert("RGB")
    sw, sh = src.size
    src_aspect = sw / sh
    dst_aspect = MAIN_W / MAIN_H
    if src_aspect > dst_aspect:
        new_w = int(round(sh * dst_aspect))
        x0 = (sw - new_w) // 2
        crop = src.crop((x0, 0, x0 + new_w, sh))
    else:
        new_h = int(round(sw / dst_aspect))
        y0 = max(0, (sh - new_h) // 5)
        crop = src.crop((0, y0, sw, y0 + new_h))
    main = crop.resize((MAIN_W, MAIN_H), Image.Resampling.LANCZOS)
    main = vignette_bars(main, 70, 120).convert("RGB")
    ensure(ROOT / "windows/main_clean.jpg")
    main.save(ROOT / "windows/main_clean.jpg", "JPEG", quality=93, subsampling=0)

    pl = src.resize((PL_W, PL_H), Image.Resampling.LANCZOS).convert("RGBA")
    dark = Image.new("RGBA", pl.size, (18, 32, 50, 132))
    pl = Image.alpha_composite(pl, dark).convert("RGB")
    pl.save(ROOT / "windows/playlist_clean.jpg", "JPEG", quality=92, subsampling=0)

    # nebula crop for EQ
    crop = src.crop((0, 0, sw, int(sh * 0.55))).resize((EQ_W, EQ_H), Image.Resampling.LANCZOS).convert("RGBA")
    panel = Image.new("RGBA", crop.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(panel)
    d.rounded_rectangle([12, 12, EQ_W - 12, EQ_H - 12], radius=22, fill=(20, 36, 56, 150))
    eq = Image.alpha_composite(crop, panel)
    ensure(ROOT / "windows/eq_clean.png")
    eq.save(ROOT / "windows/eq_clean.png", "PNG")

    menu = src.crop((0, 0, sw, int(sh * 0.4))).resize((480, 320), Image.Resampling.LANCZOS)
    menu = Image.alpha_composite(menu.convert("RGBA"), Image.new("RGBA", menu.size, (22, 36, 54, 150))).convert("RGB")
    ensure(ROOT / "menu/menuback.png")
    menu.save(ROOT / "menu/menuback.png", "PNG")


def main(windows_only: bool = False):
    MOCKUPS.mkdir(parents=True, exist_ok=True)
    if SRC.exists():
        shutil.copy2(SRC, MOCKUPS / "Winter.png")

    make_windows()
    if windows_only:
        print("Winter window backdrops written to", ROOT)
        return
    make_button(56, 56, glyph_pause, "buttons/transport_pause")
    make_button(56, 56, glyph_play, "buttons/transport_play")
    make_button(48, 48, glyph_prev, "buttons/transport_prev")
    make_button(48, 48, glyph_next, "buttons/transport_next")
    make_button(48, 48, glyph_stop, "buttons/transport_stop")
    make_button(36, 36, glyph_min, "buttons/win_min")
    make_button(36, 36, glyph_close, "buttons/win_close")
    make_button(36, 36, glyph_menu, "buttons/win_menu")
    make_button(48, 48, glyph_list, "buttons/chip_pl", checked=True)
    make_button(48, 48, glyph_eq, "buttons/chip_eq", checked=True)
    make_button(48, 48, glyph_eq, "buttons/eq_on", checked=True)
    make_button(48, 48, glyph_list, "buttons/eq_presets")
    make_play_state()
    make_play_mode()
    make_speaker()
    make_seek_volume()
    make_eq_slot()
    make_eq_thumb()
    make_row_selected()
    make_lcd()
    print("Winter skin assets written to", ROOT)


if __name__ == "__main__":
    import sys
    main(windows_only=("--windows" in sys.argv))
