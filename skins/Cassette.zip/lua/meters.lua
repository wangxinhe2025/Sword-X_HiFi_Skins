-- Two decorative VU needles use the player's mixed audio energy, not separate
-- calibrated L/R channel measurements. Slow release gives mechanical ballistics.
local levels = {0, 0}
function on_frame(dt, w, h)
    local energy = engine.is_playing() and (engine.vis_energy() or 0) or 0
    -- vis_energy already applies a 4.5x gain. Undo it before mapping -40..0 dB.
    -- Typical input 0.35..0.7 lands around 44..60%, instead of pinning at 100%.
    local rms = math.max(0, energy) / 4.5
    local db = 20 * math.log(math.max(rms, 0.0001)) / math.log(10)
    local target = math.min(1, math.max(0, (db + 40) / 40))
    for i = 1, 2 do
        local rate = target > levels[i] and (i == 1 and 12 or 10) or 3.5
        levels[i] = levels[i] + (target - levels[i]) * math.min(1, math.max(0, dt) * rate)
        -- The shared texture rests at -52 degrees, pivoting at its center.
        engine.set_role_angle(i == 1 and "main.vu_left" or "main.vu_right", levels[i] * 102)
    end
end
