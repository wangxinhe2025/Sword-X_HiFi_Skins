-- Moon 星空：星星常驻上半部夜空，偶尔闪亮（不熄灭）；偶发流星。
-- 绑定：main.window { --lua-ui-script: lua/starfield.lua; }

local STAR_COUNT = 95
local SKY_FRAC = 0.48          -- 仅在上半部星空带
local stars = {}
local meteors = {}
local timeSec = 0
local meteorCooldown = 0.5

local energySmooth = 0
local energyAvg = 0.02
local pulseEnv = 0

local function clamp(v, lo, hi)
  if v < lo then return lo end
  if v > hi then return hi end
  return v
end

local function lerp(a, b, t)
  return a + (b - a) * t
end

local function spawn_star(w, h)
  local skyH = h * SKY_FRAC
  return {
    x = math.random() * w,
    y = math.random() * skyH,
    size = 0.65 + math.random() * 1.5,
    -- 常驻亮度：始终可见，不再随 sin 掉到接近消失
    base = 0.38 + math.random() * 0.42,
    warm = math.random() < 0.14,
    -- 偶发闪亮（叠在 base 上）
    flashT = 0,
    flashTotal = 0,
    flashPeak = 0,
    flashCooldown = 0.4 + math.random() * 6.0,
    -- 极慢微呼吸（±6% 内，肉眼几乎只是「活着」）
    breathePhase = math.random() * math.pi * 2,
    breatheFreq = 0.08 + math.random() * 0.22,
  }
end

local function spawn_meteor(w, h)
  local fromLeft = math.random() < 0.55
  local x = fromLeft and (-20 + math.random() * w * 0.35) or (w * 0.55 + math.random() * w * 0.45)
  local y = -12 - math.random() * (h * SKY_FRAC * 0.35)
  local vx = (fromLeft and 1 or -1) * (260 + math.random() * 220)
  local vy = 180 + math.random() * 240
  return {
    x = x,
    y = y,
    vx = vx,
    vy = vy,
    life = 0.35 + math.random() * 0.45,
    age = 0,
    len = 18 + math.random() * 26,
    thick = 0.9 + math.random() * 0.7,
  }
end

local function update_rhythm(dt)
  if not engine.is_playing() then
    energySmooth = energySmooth * (1 - math.min(1, dt * 2.0))
    pulseEnv = pulseEnv * (1 - math.min(1, dt * 4))
    return
  end

  local e = engine.vis_energy() or 0
  local atk = math.min(1, dt * 10)
  local rel = math.min(1, dt * 3)
  if e > energySmooth then
    energySmooth = lerp(energySmooth, e, atk)
  else
    energySmooth = lerp(energySmooth, e, rel)
  end

  energyAvg = lerp(energyAvg, energySmooth, math.min(1, dt * 0.9))
  local onset = clamp(energySmooth - energyAvg * 1.12, 0, 1)
  if onset > pulseEnv then
    pulseEnv = lerp(pulseEnv, onset, math.min(1, dt * 14))
  else
    pulseEnv = pulseEnv * (1 - math.min(1, dt * 4))
  end
end

local function draw_meteor(m)
  local speed = math.sqrt(m.vx * m.vx + m.vy * m.vy)
  if speed < 1 then
    speed = 1
  end
  local dx = m.vx / speed
  local dy = m.vy / speed
  local fade = clamp(1 - m.age / m.life, 0, 1)
  local steps = clamp(math.floor(m.len / 2.6), 3, 10)
  for s = 0, steps do
    local t = s / steps
    local px = m.x - dx * m.len * t
    local py = m.y - dy * m.len * t
    local a = fade * (1 - t * 0.88) * 0.45
    engine.draw_circle(px, py, m.thick * (1 - t * 0.55), 200, 225, 255, a)
  end
  engine.draw_circle(m.x, m.y, m.thick * 1.2, 255, 255, 255, fade * 0.75)
end

local function tick_star_flash(s, dt, energy)
  s.flashCooldown = s.flashCooldown - dt
  if s.flashT > 0 then
    s.flashT = s.flashT - dt
    return
  end
  if s.flashCooldown > 0 then
    return
  end
  -- 每颗星独立随机：平均约 4–12 秒闪一次；播放时略密
  local rate = 0.06 + energy * 0.08 + pulseEnv * 0.12
  if math.random() < dt * rate then
    s.flashTotal = 0.10 + math.random() * 0.22
    s.flashT = s.flashTotal
    s.flashPeak = 0.22 + math.random() * 0.48
    s.flashCooldown = 3.5 + math.random() * 9.0
  end
end

local function star_flash_boost(s)
  if s.flashT <= 0 or s.flashTotal <= 0 then
    return 0
  end
  local u = 1 - s.flashT / s.flashTotal
  return s.flashPeak * math.sin(u * math.pi)
end

function on_init(w, h)
  stars = {}
  meteors = {}
  timeSec = 0
  meteorCooldown = 0.4 + math.random() * 0.9
  energySmooth, energyAvg, pulseEnv = 0, 0.02, 0
  for i = 1, STAR_COUNT do
    stars[i] = spawn_star(w, h)
  end
end

function on_resize(w, h)
  local skyH = h * SKY_FRAC
  for i = 1, #stars do
    local s = stars[i]
    if s.x > w then
      s.x = math.random() * w
    end
    if s.y > skyH then
      s.y = math.random() * skyH
    end
  end
end

function on_frame(dt, w, h)
  if w < 8 or h < 8 then
    return
  end
  if #stars == 0 then
    on_init(w, h)
  end

  timeSec = timeSec + dt
  update_rhythm(dt)

  local skyH = h * SKY_FRAC
  local playBoost = 1 + energySmooth * 0.25 + pulseEnv * 0.35

  for i = 1, #stars do
    local s = stars[i]
    tick_star_flash(s, dt, energySmooth)

    s.breathePhase = s.breathePhase + s.breatheFreq * dt
    local breathe = 1 + 0.06 * math.sin(s.breathePhase)

    local a = s.base * breathe * (0.92 + energySmooth * 0.12)
    a = a + star_flash_boost(s) * playBoost
    a = clamp(a, s.base * 0.88, 1)

    local sz = s.size * (1 + star_flash_boost(s) * 0.35)
    if s.warm then
      engine.draw_circle(s.x, s.y, sz, 255, 228, 195, a)
    else
      engine.draw_dot(s.x, s.y, sz, a)
    end
  end

  meteorCooldown = meteorCooldown - dt
  local maxMeteors = 5
  if meteorCooldown <= 0 and #meteors < maxMeteors then
    if math.random() < 0.42 + energySmooth * 0.35 + pulseEnv * 0.25 then
      meteors[#meteors + 1] = spawn_meteor(w, h)
    end
    meteorCooldown = (0.55 + math.random() * 1.4) / (0.7 + energySmooth * 1.1 + pulseEnv * 0.9)
  end

  local alive = {}
  for i = 1, #meteors do
    local m = meteors[i]
    m.age = m.age + dt
    m.x = m.x + m.vx * dt
    m.y = m.y + m.vy * dt
    if m.age < m.life and m.x > -80 and m.x < w + 80 and m.y < skyH + 40 then
      draw_meteor(m)
      alive[#alive + 1] = m
    end
  end
  meteors = alive
end
