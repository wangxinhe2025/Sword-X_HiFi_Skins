# Sage Minimal

以 `skins/mockups/player-mockup-sage-minimal.png` 为视觉参考重新设计的 `sword-x-skin/1` 极简皮肤。

- 主窗口左侧为完整 `530×530` 封面区域，右侧为暖白控制区。
- `windows/default_landscape.png` 是无歌曲封面时的默认雾山湖景。
- 列表采用暖白纸张与浅鼠尾草分栏，并保留极淡的山谷水印。
- 控件为透明背景的橄榄灰线性图标，最终 PNG 与 CSS 声明尺寸一致。

默认风景、列表背景与控件母版通过内置 ImageGen 生成；最终运行资源保存在 `windows/`、`buttons/`、`edited/`、`sliders/` 与 `icons/`，`generated/` 保留母版及检查预览。
