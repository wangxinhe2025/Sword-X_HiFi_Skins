# earth (Star) 皮肤：play-mode 四态，50px，冰蓝玻璃圆角方钮（对齐 transport/chip）
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

$skinRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$outDir = Join-Path $skinRoot 'edited\main_play_mode'
New-Item -ItemType Directory -Force -Path $outDir | Out-Null

function New-C([int]$a, [int]$r, [int]$g, [int]$b) {
    return [System.Drawing.Color]::FromArgb($a, $r, $g, $b)
}
function PF([float]$x, [float]$y) { return [System.Drawing.PointF]::new($x, $y) }

function Save-Bmp([System.Drawing.Bitmap]$bmp, [string]$path) {
    $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
}

function New-RoundRectPath([float]$x, [float]$y, [float]$w, [float]$h, [float]$r) {
    $p = New-Object System.Drawing.Drawing2D.GraphicsPath
    $d = $r * 2
    $p.AddArc($x, $y, $d, $d, 180, 90)
    $p.AddArc(($x + $w - $d), $y, $d, $d, 270, 90)
    $p.AddArc(($x + $w - $d), ($y + $h - $d), $d, $d, 0, 90)
    $p.AddArc($x, ($y + $h - $d), $d, $d, 90, 90)
    $p.CloseFigure()
    return $p
}

# 玻璃圆角方钮：外发光 + 深蓝盘 + 青描边 + 顶部高光
function Begin-GlassBtn([int]$size) {
    $bmp = New-Object System.Drawing.Bitmap $size, $size, ([System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'
    $g.PixelOffsetMode = 'HighQuality'
    $g.TextRenderingHint = 'AntiAliasGridFit'
    $g.Clear([System.Drawing.Color]::Transparent)

    $pad = [Math]::Max(2, [int]($size * 0.06))
    $rr = [Math]::Max(8.0, $size * 0.28)
    $x = [float]$pad; $y = [float]$pad
    $w = [float]($size - 2 * $pad); $h = [float]($size - 2 * $pad)

    # 外圈青色微光
    for ($i = 4; $i -ge 1; $i--) {
        $a = [int](8 + $i * 6)
        $br = New-Object System.Drawing.SolidBrush (New-C $a 80 200 255)
        $pathGlow = New-RoundRectPath ($x - $i) ($y - $i) ($w + 2 * $i) ($h + 2 * $i) ($rr + $i * 0.4)
        $g.FillPath($br, $pathGlow)
        $pathGlow.Dispose(); $br.Dispose()
    }

    $facePath = New-RoundRectPath $x $y $w $h $rr
    # 盘面径向感：上略浅
    $faceBr = New-Object System.Drawing.Drawing2D.LinearGradientBrush (
        [System.Drawing.RectangleF]::new($x, $y, $w, $h),
        (New-C 245 18 42 72),
        (New-C 245 8 18 36),
        90.0
    )
    $g.FillPath($faceBr, $facePath)
    $faceBr.Dispose()

    # 描边：外层亮青 + 内层更亮
    $penOuter = New-Object System.Drawing.Pen (New-C 255 120 210 245), ([Math]::Max(1.6, $size * 0.045))
    $g.DrawPath($penOuter, $facePath)
    $penOuter.Dispose()

    $inset = [Math]::Max(2.5, $size * 0.08)
    $innerPath = New-RoundRectPath ($x + $inset) ($y + $inset) ($w - 2 * $inset) ($h - 2 * $inset) ([Math]::Max(5.0, $rr - $inset))
    $penInner = New-Object System.Drawing.Pen (New-C 200 200 240 255), ([Math]::Max(1.0, $size * 0.028))
    $g.DrawPath($penInner, $innerPath)
    $penInner.Dispose()
    $innerPath.Dispose()
    $facePath.Dispose()

    # 顶部玻璃高光弧
    $hiBrush = New-Object System.Drawing.SolidBrush (New-C 55 230 245 255)
    $hi = New-RoundRectPath ($x + $w * 0.12) ($y + $h * 0.08) ($w * 0.76) ($h * 0.28) ($rr * 0.55)
    $g.FillPath($hiBrush, $hi)
    $hi.Dispose(); $hiBrush.Dispose()

    # 图标色：lcd-fg / accent 偏亮
    $ink = New-C 255 232 244 255
    return @{ Bmp = $bmp; G = $g; Size = $size; Ink = $ink }
}

function Draw-SequentialGlyph($g, $ink, [int]$size) {
    $cx = $size / 2.0; $cy = $size / 2.0
    $s = $size * 0.13
    $br = New-Object System.Drawing.SolidBrush $ink
    $ah = $s * 0.95; $aw = $s * 0.70
    foreach ($ox in @(-1.35, -0.15, 1.05)) {
        $x = $cx + $s * $ox
        $g.FillPolygon($br, @(
            (PF ($x + $aw) $cy),
            (PF ($x - $aw * 0.35) ($cy - $ah)),
            (PF ($x - $aw * 0.35) ($cy + $ah))
        ))
    }
    $br.Dispose()
}

function Draw-LoopAllGlyph($g, $ink, [int]$size) {
    $cx = $size / 2.0; $cy = $size / 2.0
    $s = $size * 0.16
    $pw = [Math]::Max(1.8, $size * 0.055)
    $pen = New-Object System.Drawing.Pen $ink, $pw
    $pen.StartCap = 'Round'; $pen.EndCap = 'Round'
    $br = New-Object System.Drawing.SolidBrush $ink
    $left = $cx - $s * 1.35; $right = $cx + $s * 1.05
    $top = $cy - $s * 0.95; $bot = $cy + $s * 0.95
    $rad = $s * 0.95
    $g.DrawLine($pen, $left + $rad * 0.15, $top, $right - $rad * 0.2, $top)
    $g.DrawArc($pen, [float]($right - $rad), [float]$top, [float]$rad, [float]($bot - $top), -90, 180)
    $g.DrawLine($pen, $right - $rad * 0.2, $bot, $left + $rad * 0.15, $bot)
    $g.DrawArc($pen, [float]$left, [float]$top, [float]$rad, [float]($bot - $top), 90, 180)
    $ah = $s * 0.55
    $ax = $right - $rad * 0.05
    $g.FillPolygon($br, @((PF ($ax + $ah * 0.85) $top), (PF ($ax - $ah * 0.15) ($top - $ah * 0.55)), (PF ($ax - $ah * 0.15) ($top + $ah * 0.55))))
    $bx = $left + $rad * 0.05
    $g.FillPolygon($br, @((PF ($bx - $ah * 0.85) $bot), (PF ($bx + $ah * 0.15) ($bot - $ah * 0.55)), (PF ($bx + $ah * 0.15) ($bot + $ah * 0.55))))
    $pen.Dispose(); $br.Dispose()
}

function Draw-ShuffleGlyph($g, $ink, [int]$size) {
    $cx = $size / 2.0; $cy = $size / 2.0
    $s = $size * 0.16
    $pw = [Math]::Max(1.8, $size * 0.055)
    $pen = New-Object System.Drawing.Pen $ink, $pw
    $pen.StartCap = 'Round'; $pen.EndCap = 'Round'
    $br = New-Object System.Drawing.SolidBrush $ink
    $lx = $cx - $s * 1.35; $rx = $cx + $s * 0.75
    $ty = $cy - $s * 1.0; $by = $cy + $s * 1.0
    $g.DrawBezier($pen, (PF $lx $ty), (PF ($cx - $s * 0.15) $ty), (PF ($cx + $s * 0.15) $by), (PF $rx $by))
    $g.DrawBezier($pen, (PF $lx $by), (PF ($cx - $s * 0.15) $by), (PF ($cx + $s * 0.15) $ty), (PF $rx $ty))
    $ah = $s * 0.65
    $g.FillPolygon($br, @((PF ($rx + $ah * 0.65) $by), (PF ($rx - $ah * 0.25) ($by - $ah * 0.55)), (PF ($rx - $ah * 0.25) ($by + $ah * 0.55))))
    $g.FillPolygon($br, @((PF ($rx + $ah * 0.65) $ty), (PF ($rx - $ah * 0.25) ($ty - $ah * 0.55)), (PF ($rx - $ah * 0.25) ($ty + $ah * 0.55))))
    $pen.Dispose(); $br.Dispose()
}

function Draw-LoopOneGlyph($g, $ink, [int]$size) {
    $cx = $size / 2.0; $cy = $size / 2.0
    $s = $size * 0.155
    $pen = New-Object System.Drawing.Pen $ink, ([Math]::Max(1.8, $size * 0.055))
    $pen.StartCap = 'Round'; $pen.EndCap = 'Round'
    $br = New-Object System.Drawing.SolidBrush $ink
    $arc = [System.Drawing.Rectangle]::new(
        [int]($cx - $s * 1.2), [int]($cy - $s * 1.05),
        [int]($s * 2.4), [int]($s * 2.1)
    )
    $g.DrawArc($pen, $arc, 35, 290)
    $ax = $cx + $s * 0.55; $ay = $cy - $s * 1.05; $ah = $s * 0.65
    $g.FillPolygon($br, @(
        (PF ($ax + $ah * 0.15) ($ay - $ah * 0.15)),
        (PF ($ax - $ah * 0.75) ($ay + $ah * 0.15)),
        (PF ($ax + $ah * 0.35) ($ay + $ah * 0.85))
    ))
    $fs = [Math]::Max(10.0, $size * 0.28)
    $font = New-Object System.Drawing.Font 'Segoe UI', $fs, ([System.Drawing.FontStyle]::Bold), ([System.Drawing.GraphicsUnit]::Pixel)
    $sf = New-Object System.Drawing.StringFormat
    $sf.Alignment = 'Center'; $sf.LineAlignment = 'Center'
    $g.DrawString('1', $font, $br, [System.Drawing.RectangleF]::new(0, 1, $size, $size), $sf)
    $font.Dispose(); $sf.Dispose()
    $pen.Dispose(); $br.Dispose()
}

$size = 50
$modes = @(
    @{ n = 'sequential'; draw = { param($j) Draw-SequentialGlyph $j.G $j.Ink $j.Size } },
    @{ n = 'loop_all';   draw = { param($j) Draw-LoopAllGlyph   $j.G $j.Ink $j.Size } },
    @{ n = 'shuffle';    draw = { param($j) Draw-ShuffleGlyph    $j.G $j.Ink $j.Size } },
    @{ n = 'loop_one';   draw = { param($j) Draw-LoopOneGlyph   $j.G $j.Ink $j.Size } }
)

foreach ($m in $modes) {
    $j = Begin-GlassBtn $size
    & $m.draw $j
    $j.G.Dispose()
    $path = Join-Path $outDir ("{0}.png" -f $m.n)
    Save-Bmp $j.Bmp $path
    $j.Bmp.Dispose()
    Write-Host "  wrote $path"
}
Copy-Item (Join-Path $outDir 'sequential.png') (Join-Path $outDir 'normal.png') -Force
Write-Host 'Done.'
